#!/bin/sh

###
# Desenvolvido por Videosoft < https://www.videosoft.com.br >
#
# Este script verifica as permissões e possíveis falhas no VS AutoPag SE
#
# Revisado: 20.07.2020 por Rodrigo Bruner < rodrigo.bruner@videosoft.com.br >
###

#Nome da aplicação
VS_APP="vs-food-launcher"

#Diretório raiz da aplicação
VS_APP_PATH="/opt/videosoft/vs-food-launcher"


GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Permissão de escrita no diretório Log
logPermission()
{
	# Diretório de log
	VS_LOG_PATH="$VS_APP_PATH/log/"

	if [ -d $VS_LOG_PATH ]; then
		if [ $(stat -c "%a" $VS_LOG_PATH) != "777" ]; then
			chmod 0777 -R $VS_LOG_PATH
			STATUS="${BLUE}CORRIGIDO${NC}"
		else
			STATUS="${GREEN}OK${NC}"
		fi
		echo "Permissão do diretório de log [$STATUS]"
	else
		mkdir -p $VS_LOG_PATH
		chmod 0777 -R $VS_LOG_PATH
		STATUS="${BLUE}CORRIGIDO${NC}"
		echo "Criado diretório de log [$STATUS]"
	fi
}

# Verifica se existe os arquivos de configuração
checkFiles()
{
	# Verifica o arquivo de configuração
	if [ -f "$VS_APP_PATH/.env" ]; then
		STATUS="${GREEN}OK${NC}"
		echo "Arquivo de configuraçao(.env) detectado [$STATUS]"
	else
		STATUS="${RED}ERRO${NC}"
		echo "Arquivo de configuraçao(.env) não detectado [$STATUS]"
	fi


	# Verifica o arquivo de licença
	if [ -f "$VS_APP_PATH/data.data" ]; then
		STATUS="${GREEN}OK${NC}"
		echo "Arquivo de configuração(data.data) detectado [$STATUS]"
	else
		STATUS="${RED}ERRO${NC}"
		echo "Arquivo de configuração(data.data) não detectado [$STATUS]"
	fi
}

main()
{
	clear
	echo "Iniciando autotest do $VS_APP"
	logPermission
	#checkFiles
	echo "Fim do autotest"
}
main
